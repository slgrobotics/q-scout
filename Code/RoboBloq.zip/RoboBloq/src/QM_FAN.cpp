#include "QM_QMINDX.h"
#include "analogWrite.h"

QM_Port FAN_port;

QM_FAN::QM_FAN(uint8_t port)
{
    FAN_port.GPIO_Init();
    FAN_port.Select_Port(port);
    pinMode(SCL0_COM, OUTPUT);
    pinMode(SDA0_COM, OUTPUT);
    digitalWrite(SCL0_COM,HIGH);
    digitalWrite(SDA0_COM,HIGH);
}

void QM_FAN::QM_FAN_SET(uint8_t Speed, uint8_t Dir)
{
    pinMode(SCL0_COM, OUTPUT);
    pinMode(SDA0_COM, OUTPUT);
    Speed = constrain(Speed, 0, 255);
    if(Speed == 0)
    {
        ledcDetachPin(SCL0_COM);
        ledcDetachPin(SDA0_COM);
        digitalWrite(SCL0_COM,HIGH);
        digitalWrite(SDA0_COM,HIGH);
    }
    else
    {
        Speed = 255 - Speed;
        if (Dir == 0)
        {
            digitalWrite(SDA0_COM, HIGH);
            analogWrite(SCL0_COM, Speed);
        }
        else
        {
            digitalWrite(SCL0_COM, HIGH);
            analogWrite(SDA0_COM, Speed);
        }
    }
}
