#include "QM_DIGITALDISPLAY.h"
#include "QM_PORT.h"

QM_Port digitaldisplay_port;

uint8_t DIGITAL_tab[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71, 0X00};

QM_DIGITALDISPLAY::QM_DIGITALDISPLAY(void) : QM_SoftI2CMaster(0)
{
    digitaldisplay_port.GPIO_Init();
    QM_SoftI2CMaster::SetMode(0);
}

QM_DIGITALDISPLAY::QM_DIGITALDISPLAY(uint8_t port) : QM_SoftI2CMaster(port)
{
    digitaldisplay_port.GPIO_Init();
    digitaldisplay_port.Select_Port(port);
    QM_SoftI2CMaster::SetMode(0);
}

void QM_DIGITALDISPLAY::QM_DIGITALDISPLAY_Init(void)
{
    QM_SoftI2CMaster::I2C_Star();
    QM_SoftI2CMaster::I2C_Write(0X48);
    QM_SoftI2CMaster::I2C_GetAck();
    QM_SoftI2CMaster::I2C_Write(0X31);
    QM_SoftI2CMaster::I2C_Stop();
    QM_SoftI2CMaster::I2C_Stop();
}

void QM_DIGITALDISPLAY::QM_DIGITALDISPLAY_SET(uint8_t Address, uint8_t Data)
{
    if (Address < 1)
        return;
    QM_SoftI2CMaster::I2C_Star();
    QM_SoftI2CMaster::I2C_Write(0X68 + 2 * (Address - 1));
    QM_SoftI2CMaster::I2C_GetAck();
    if (Data & 0X80)
        QM_SoftI2CMaster::I2C_Write(DIGITAL_tab[Data & 0x7F] | 0X80);
    else
        QM_SoftI2CMaster::I2C_Write(DIGITAL_tab[Data & 0x7F]);
    QM_SoftI2CMaster::I2C_Stop();
    QM_SoftI2CMaster::I2C_Stop();
}

void QM_DIGITALDISPLAY::QM_DIGITALDISPLAY_SET(uint8_t port, uint8_t Address, uint8_t Data)
{
    digitaldisplay_port.Select_Port(port);
    if (Address < 1)
        return;
    QM_SoftI2CMaster::I2C_Star();
    QM_SoftI2CMaster::I2C_Write(0X68 + 2 * (Address - 1));
    QM_SoftI2CMaster::I2C_GetAck();
    if (Data & 0X80)
        QM_SoftI2CMaster::I2C_Write(DIGITAL_tab[Data & 0x7F] | 0X80);
    else
        QM_SoftI2CMaster::I2C_Write(DIGITAL_tab[Data & 0x7F]);
    QM_SoftI2CMaster::I2C_Stop();
    QM_SoftI2CMaster::I2C_Stop();
}
/*
   Clear All Digital Display
*/
void QM_DIGITALDISPLAY::Clear(void)
{
    QM_DIGITALDISPLAY_SET(0X68 + 2 * 0, 0X10);
    QM_DIGITALDISPLAY_SET(0X68 + 2 * 1, 0X10);
    QM_DIGITALDISPLAY_SET(0X68 + 2 * 2, 0X10);
    QM_DIGITALDISPLAY_SET(0X68 + 2 * 3, 0X10);
}

void QM_DIGITALDISPLAY::Clear(uint8_t port)
{
    digitaldisplay_port.Select_Port(port);
    QM_DIGITALDISPLAY_SET(0X68 + 2 * 0, 0X10);
    QM_DIGITALDISPLAY_SET(0X68 + 2 * 1, 0X10);
    QM_DIGITALDISPLAY_SET(0X68 + 2 * 2, 0X10);
    QM_DIGITALDISPLAY_SET(0X68 + 2 * 3, 0X10);
}