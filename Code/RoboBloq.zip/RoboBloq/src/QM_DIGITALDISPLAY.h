#ifndef QM_DIGITALDISPLAY_H
#define QM_DIGITALDISPLAY_H

#include <inttypes.h>
#include <Arduino.h>
#include "QM_PORT.h" 
#include "QM_SOFTI2CMASTER.h"


class QM_DIGITALDISPLAY : public QM_SoftI2CMaster
{
  public : 
        QM_DIGITALDISPLAY(void);
		QM_DIGITALDISPLAY(uint8_t port);
        void QM_DIGITALDISPLAY_Init(void);
		void QM_DIGITALDISPLAY_SET(uint8_t Address,uint8_t Data);
        void Clear(void);
		void QM_DIGITALDISPLAY_SET(uint8_t port, uint8_t Address,uint8_t Data);
        void Clear(uint8_t port);
};
#endif 
