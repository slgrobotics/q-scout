#ifndef QM_SoftI2CMaster_h
#define QM_SoftI2CMaster_h

#include <Arduino.h>
#include <inttypes.h>
#include "QM_PORT.h" 

#define _SOFTI2CMASTER_VERSION 12  // software version of this library


class QM_SoftI2CMaster : public QM_Port
{
public:
    QM_SoftI2CMaster(uint8_t _sdapin,uint8_t _sclpin);
    QM_SoftI2CMaster(uint8_t port);
    void SetMode(uint8_t mode);
    
 //   QM_SoftI2CMaster(uint8_t port,uint8_t mode);
    void I2C_Star(void);
    void I2C_Write(uint8_t dat);
    uint8_t I2C_Read(void);
    uint8_t I2C_GetAck(void);
    void I2C_PutAck(uint8_t ack);
    void I2C_Stop(void);
    void beginTransmission(uint8_t slaveaddress);
    void endTransmission(void);
    void send(uint8_t data);
 private:
    uint8_t _SDA;
    uint8_t _SCL;   
    uint8_t _MODE;
};

#endif
