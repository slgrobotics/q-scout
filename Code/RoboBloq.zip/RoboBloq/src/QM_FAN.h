#ifndef QM_FAN_H
#define QM_FAN_H

#include <stdint.h>
#include <stdbool.h>
#include <Arduino.h>

#include "QM_PORT.h"

class QM_FAN
{
public:
    QM_FAN(uint8_t port);
    void QM_FAN_SET(uint8_t Speed, uint8_t Dir);
};

#endif
