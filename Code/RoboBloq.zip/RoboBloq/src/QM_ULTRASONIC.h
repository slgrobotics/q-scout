#ifndef QM_Ultrasonic_H
#define QM_Ultrasonic_H

#include <inttypes.h>
#include <Arduino.h>
#include "QM_PORT.h" 
#include "Wire.h"


//class QM_Ultrasonic : public TwoWire
class QM_Ultrasonic
{
  public : 
    QM_Ultrasonic(void);
    QM_Ultrasonic(uint8_t port);
    void QM_Ultrasonic_SetRGB(uint8_t SlaveAddress,uint8_t RegisterAddress,uint8_t Red,uint8_t Green,uint8_t Blue);
    double distanceCm(uint16_t = 250);
    double distanceInch(uint16_t = 180);
    long   measure(unsigned long = 30000);
    double KalmanFilter(const double ResrcData,double ProcessNiose_Q,double MeasureNoise_R);
	double Uldistance();
	double Uldistance(uint8_t port);
	void   Swap(double  A[], int i, int j);
	void   BubbleSort(double A[], int n);
   private:
    double max_distance=300;
    volatile uint8_t  _SignalPin;
    volatile bool _measureFlag;
    volatile long _lastEnterTime;
    volatile float _measureValue;
};
#endif 
