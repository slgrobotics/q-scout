#include "QM_BUZZER.h"
#include "ESP32Tone.h"

// notes in the melody:
int melody[] = {
    NOTE_G4, //5
    NOTE_G4, //5
    NOTE_A4, //6
    NOTE_G4, //5
    NOTE_C5, //1.
    NOTE_B4, //7
    0,
    NOTE_G4, //5
    NOTE_G4, //5
    NOTE_A4, //6
    NOTE_G4, //5
    NOTE_D5, //2.
    NOTE_C5, //1.
    0,
    NOTE_G4, //5
    NOTE_G4, //5
    NOTE_G5, //5.
    NOTE_E5, //3.
    NOTE_C5, //1.
    NOTE_B4, //7
    NOTE_A4, //6
    0,
    NOTE_F5, //4.
    NOTE_F5, //4.
    NOTE_E5, //3.
    NOTE_C5, //1.
    NOTE_D5, //2.
    NOTE_C5, //1.
    0,
};

int noteDurations[] = {
    8,
    8,
    4,
    4,
    4,
    4,
    4,
    8,
    8,
    4,
    4,
    4,
    4,
    4,
    8,
    8,
    4,
    4,
    4,
    4,
    2,
    8,
    8,
    8,
    4,
    4,
    4,
    2,
    4,
};

/*
 * 
 */
QM_Buzzer::QM_Buzzer(int pin)
{
    buzzer_pin = pin;
}

/*
 * 
 */
void QM_Buzzer::setPin(int pin)
{
    buzzer_pin = pin;
}

/*
 * 
 */
void QM_Buzzer::Tone(int pin, uint16_t frequency, uint32_t duration)
{
    tone(pin, frequency, duration, 0);
}
/*
   * 
   */
void QM_Buzzer::Tone(uint16_t frequency, uint32_t duration)
{
    tone(Buzzer_Pin, frequency, duration, 0);
    noTone(Buzzer_Pin, 0);
}
/*
   * 
   */
void QM_Buzzer::NoTone(int pin)
{
    noTone(pin, 0);
}
/*
 * 
 */
void QM_Buzzer::NoTone(void)
{
    noTone(Buzzer_Pin, 0);
}
