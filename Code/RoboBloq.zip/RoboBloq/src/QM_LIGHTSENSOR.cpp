#include "QM_LIGHTSENSOR.h"

QM_Port lightsensor_port;

QM_LightSensor::QM_LightSensor(void)
{
    lightsensor_port.GPIO_Init();
}

QM_LightSensor::QM_LightSensor(uint8_t port)
{
    lightsensor_port.GPIO_Init();
    lightsensor_port.Select_Port(port);
}

uint16_t QM_LightSensor::GetLight(void)
{
    uint16_t value;
    pinMode(_dat, INPUT);
    float duration = pulseIn(_dat, HIGH, 4000);

    delay(10); // 此处必须有延时

    // Serial.print("light sensor duration:");
    // Serial.println(duration);
    if(digitalRead(_dat) && (duration == 0))
        duration = 1000;
    if (duration <= 1000)
        value = 1000 - duration;
    else
        value = 0;
    return value;
}

uint16_t QM_LightSensor::GetLightValue(void)
{
    int i = 0;
    uint16_t Value[10];
    uint16_t max = 0, min = 0;
    uint32_t sum = 0;
    uint16_t return_value = 0;
    for (i = 0; i < 10; i++)
    {
        Value[i] = GetLight();
        if (Value[i] > max)
            max = Value[i];
        if (Value[i] < min)
            min = Value[i];
        sum += Value[i];
    }
    sum = sum - max - min;
    return_value = sum / 8;
    return return_value;
}

uint16_t QM_LightSensor::GetLightValue(uint8_t port)
{
    lightsensor_port.Select_Port(port);

    int i = 0;
    uint16_t Value[10];
    uint16_t max = 0, min = 0;
    uint32_t sum = 0;
    uint16_t return_value = 0;
    for (i = 0; i < 10; i++)
    {
        Value[i] = GetLight();
        if (Value[i] > max)
            max = Value[i];
        if (Value[i] < min)
            min = Value[i];
        sum += Value[i];
    }
    sum = sum - max - min;
    return_value = sum / 8;
    return return_value;
}