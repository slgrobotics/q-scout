#include "QM_GYRO.h"
#include <string.h>
#include "QM_PORT.h"

QM_Port gyro_port;

QM_GYRO::QM_GYRO(void) : QM_SoftI2CMaster(0)
{

    QM_SoftI2CMaster::SetMode(1);
}

QM_GYRO::QM_GYRO(uint8_t port) : QM_SoftI2CMaster(port)
{
    gyro_port.GPIO_Init();
    gyro_port.Select_Port(port);
    QM_SoftI2CMaster::SetMode(1);
    Device_Address = GYRO_ADDRESS_GND;
}

void QM_GYRO::ReadData(uint8_t start_regaddress, uint8_t *buffer, uint8_t datalen)
{

    QM_SoftI2CMaster::I2C_Star();
    QM_SoftI2CMaster::I2C_Write(Device_Address << 1 | 0x00);
    QM_SoftI2CMaster::I2C_GetAck();
    QM_SoftI2CMaster::I2C_Write(start_regaddress);
    QM_SoftI2CMaster::I2C_GetAck();
    QM_SoftI2CMaster::I2C_Stop();
    // ets_delay_us(15);
    delayMicroseconds(15);
    QM_SoftI2CMaster::I2C_Star();
    QM_SoftI2CMaster::I2C_Write(Device_Address << 1 | 0x01);
    QM_SoftI2CMaster::I2C_GetAck();
    datalen = datalen - 1;
    while (datalen--)
    {
        *buffer = QM_SoftI2CMaster::I2C_Read();
        QM_SoftI2CMaster::I2C_PutAck(0);
        buffer++;
    }
    *buffer = QM_SoftI2CMaster::I2C_Read();
    QM_SoftI2CMaster::I2C_PutAck(1);
    QM_SoftI2CMaster::I2C_Stop();
}

void QM_GYRO::WriteData(uint8_t start_regaddress, uint8_t *buffer, uint8_t datalen)
{

    QM_SoftI2CMaster::I2C_Star();
    QM_SoftI2CMaster::I2C_Write(Device_Address << 1 | 0x00);
    QM_SoftI2CMaster::I2C_GetAck();
    QM_SoftI2CMaster::I2C_Write(start_regaddress);
    QM_SoftI2CMaster::I2C_GetAck();
    while (datalen--)
    {
        QM_SoftI2CMaster::I2C_Write(*buffer);
        QM_SoftI2CMaster::I2C_GetAck();

        buffer++;
    }
    QM_SoftI2CMaster::I2C_Stop();
}

void QM_GYRO::WriteReg(uint8_t start_regaddress, uint8_t buffer)
{
    QM_SoftI2CMaster::I2C_Star();
    QM_SoftI2CMaster::I2C_Write(Device_Address << 1 | 0x00);
    QM_SoftI2CMaster::I2C_GetAck();
    QM_SoftI2CMaster::I2C_Write(start_regaddress);
    QM_SoftI2CMaster::I2C_GetAck();
    QM_SoftI2CMaster::I2C_Write(buffer);
    QM_SoftI2CMaster::I2C_GetAck();
    QM_SoftI2CMaster::I2C_Stop();
}

void QM_GYRO::begin(void)
{
    gSensitivity = 65.5;
    // gSensitivity = 131.1;

    AngleX = 0;
    AngleY = 0;
    AngleZ = 0;

    GyroX = 0;
    GyroY = 0;
    GyroZ = 0;

    AccX = 0;
    AccY = 0;
    AccZ = 0;

    GyroXoffset = 0;
    GyroYoffset = 0;
    GyroZoffset = 0;

    delay(100);
    WriteReg(0x6B, 0X00);
    delay(30);
    WriteReg(0X1A, 0X01);
    WriteReg(0X1B, 0X08);
    delay(50);
    // deviceCalibration();
}

void QM_GYRO::Update(void)
{
    static unsigned long last_time = 0;
    double dt, filter_coefficient;
    double ax, ay, az;
    ReadData(0x3b, i2cData, 14);
    AccX = ((i2cData[0] << 8) | i2cData[1]);
    AccY = ((i2cData[2] << 8) | i2cData[3]);
    AccZ = ((i2cData[4] << 8) | i2cData[5]);
    GyroX = ((((int8_t)i2cData[8] << 8) | (int8_t)i2cData[9]) - GyroXoffset) / gSensitivity;
    GyroY = ((((int8_t)i2cData[10] << 8) | (int8_t)i2cData[11]) - GyroYoffset) / gSensitivity;
    GyroZ = ((((int8_t)i2cData[12] << 8) | (int8_t)i2cData[13]) - GyroZoffset) / gSensitivity;
    // Serial.print("AccX:");
    // Serial.println(AccX);
    // Serial.print("AccY:");
    // Serial.println(AccY);
    // Serial.print("AccZ:");
    // Serial.println(AccZ);

    // Serial.print("GyroX:");
    // Serial.print(GyroX);
    // Serial.print(" GyroY:");
    // Serial.print(GyroY);
    // Serial.print(" GyroZ:");
    // Serial.println(GyroZ);
    // Serial.print("i2cData[0]:");
    // Serial.print(i2cData[0]);
    // Serial.print("  i2cData[1]:");
    // Serial.print(i2cData[1]);
    // Serial.print("  i2cData[2]:");
    // Serial.print(i2cData[2]);
    // Serial.print("  i2cData[3]:");
    // Serial.print(i2cData[3]);
    // Serial.print("  i2cData[4]:");
    // Serial.print(i2cData[4]);
    // Serial.print("  i2cData[5]:");
    // Serial.println(i2cData[5]);

    // Serial.print("i2cData[8]:");
    // Serial.print(i2cData[8]);
    // Serial.print("  i2cData[9]:");
    // Serial.print(i2cData[9]);
    // Serial.print("  i2cData[10]:");
    // Serial.print(i2cData[10]);
    // Serial.print("  i2cData[11]:");
    // Serial.print(i2cData[11]);
    // Serial.print("  i2cData[12]:");
    // Serial.print(i2cData[12]);
    // Serial.print("  i2cData[13]:");
    // Serial.println(i2cData[13]);

    ax = atan2(AccX, sqrt(pow(AccY, 2) + pow(AccZ, 2))) * 180 / 3.1415926;
    ay = atan2(AccY, sqrt(pow(AccX, 2) + pow(AccZ, 2))) * 180 / 3.1415926;

    dt = (double)(millis() - last_time) / 1000;
    last_time = millis();

    if (AccZ > 0)
    {
        AngleX = AngleX - GyroY * dt;
        AngleY = AngleY + GyroX * dt;
    }
    else
    {
        AngleX = AngleX + GyroY * dt;
        AngleY = AngleY - GyroX * dt;
    }
    AngleZ += GyroZ * dt;
    AngleZ = AngleZ - 360 * floor(AngleZ / 360);

    /*
     complementary filter
     set 0.5sec = tau = dt * A / (1 - A)
     so A = tau / (tau + dt)
      */
    filter_coefficient = 0.5 / (0.5 + dt);
    AngleX = AngleX * filter_coefficient + ax * (1 - filter_coefficient);
    AngleY = AngleY * filter_coefficient + ay * (1 - filter_coefficient);
}

void QM_GYRO::FastUpdate(void)
{
    static unsigned long last_time = 0;
    double dt, filter_coefficient;
    double ax, ay, az;
    ReadData(0x3b, i2cData, 14);
    AccX = ((i2cData[0] << 8) | i2cData[1]);
    AccY = ((i2cData[2] << 8) | i2cData[3]);
    AccZ = ((i2cData[4] << 8) | i2cData[5]);
    GyroX = (((i2cData[8] << 8) | i2cData[9]) - GyroXoffset) / gSensitivity;
    GyroY = (((i2cData[10] << 8) | i2cData[11]) - GyroYoffset) / gSensitivity;
    GyroZ = (((i2cData[12] << 8) | i2cData[13]) - GyroZoffset) / gSensitivity;

    Serial.print("AccX:");
    Serial.println(AccX);
    Serial.print("AccY:");
    Serial.println(AccY);
    Serial.print("AccZ:");
    Serial.println(AccZ);

    ax = atan2(AccX, sqrt(pow(AccY, 2) + pow(AccZ, 2))) * 180 / 3.1415926;
    ay = atan2(AccY, sqrt(pow(AccX, 2) + pow(AccZ, 2))) * 180 / 3.1415926;

    dt = (double)(millis() - last_time) / 1000;
    last_time = millis();

    if (AccZ > 0)
    {
        AngleX = AngleX - GyroY * dt;
        AngleY = AngleY + GyroX * dt;
    }
    else
    {
        AngleX = AngleX + GyroY * dt;
        AngleY = AngleY - GyroX * dt;
    }
    AngleZ += GyroZ * dt;
    AngleZ = AngleZ - 360 * floor(AngleZ / 360);

    AngleX = AngleX * 0.98 + ax * 0.02;
    AngleY = AngleY * 0.98 + ay * 0.02;
}

double QM_GYRO::getAngleX(void)
{
    return AngleX * (-1);
}

double QM_GYRO::getAngleY(void)
{
    return AngleY * (-1);
}
double QM_GYRO::getAngleZ(void)
{
    return AngleZ;
}

double QM_GYRO::getGyroX(void)
{
    return GyroX;
}

double QM_GYRO::getGyroY(void)
{
    return GyroY;
}
double QM_GYRO::getGyroZ(void)
{
    return GyroZ;
}

int16_t QM_GYRO::getAccX(void)
{
    return AccX;
}

int16_t QM_GYRO::getAccY(void)
{
    return AccY;
}
int16_t QM_GYRO::getAccZ(void)
{
    return AccZ;
}

void QM_GYRO::deviceCalibration(void)
{
    uint16_t x = 0;
    uint16_t num = 500;
    long xsum = 0, ysum = 0, zsum = 0;

    for (x = 0; x < num; x++)
    {
        ReadData(0x43, i2cData, 6);
        xsum += ((i2cData[0] << 8) | i2cData[1]);
        ysum += ((i2cData[2] << 8) | i2cData[3]);
        zsum += ((i2cData[4] << 8) | i2cData[5]);
    }

    GyroXoffset = xsum / num;
    GyroYoffset = ysum / num;
    GyroZoffset = zsum / num;
}
