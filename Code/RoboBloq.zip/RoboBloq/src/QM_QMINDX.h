#ifndef _QM_QMINDX_H
#define _QM_QMINDX_H

#include <stdint.h>
#include <stdbool.h>
#include <Arduino.h>

#include "QM_RGBLEDONBOARD.h"
#include "QM_RGBLEDMOUDLE.h"
#include "QM_PORT.h"
#include "QM_LINEFOLLOWER.h"
#include "QM_BUZZER.h"
#include "QM_DCMOTORONBOARD.h"
#include "QM_Ultrasonic.h"
#include "QM_LEDMATRIX.h"
#include "QM_DIGITALDISPLAY.h"
#include "QM_LIGHTSENSOR.h"
#include "QM_SOUNDSENSOR.h"
#include "QM_PIRSENSOR.h"
#include "QM_TEMPANDHUMI.h"
#include "QM_GYROSCOPES.h"
#include "QM_GYRO.h"
#include "QM_ICM42605.h"
#include "QM_COLORSENSOR.h"
#include "QM_FAN.h"

/*
 *  Hardware Information
 */
#define MachineType                           2         // 1---K1, 2---K2

#if MachineType == 1
    #define DeviceType                        4         //主控类型          
#elif MachineType == 2 
    #define DeviceType                        3         //主控类型          
#endif
#define HardwareVersion                       0         //硬件版本
#define SoftwareVersion                       01        //软件版本    

/*
 *    WORK MODE
 */
 #define Remote_Control_Mode               0X00           //遥控模式
 #define Ultrasonic_Mode                   0X01           //超声波蔽障模式
 #define Line_Follower_Mode                0x02           //巡线模式
 #define Dinosaur_Ultrasonic_Mode          0x03           //恐龙模式蔽障模式
 #define Alligator_Ultrasonic_Mode         0x04           //鳄鱼传统蔽障模式
 #define Scan_Mode                         0X10           //扫描避障模式
 #define SearchLight_Mode                  0X11           //扫描避障模式

/*
 *   Action
 */
#define   Hardware                            0x01          //查询版本信息
#define   Device_Type                         0x02          //查询设备信息
#define   Device_All                          0x03          //查询所有设备信息
#define   Device_Motor                        0x04          //查询电机接口信息
#define   Device_Port                         0x05          //查询端口信息
#define   Led_SET                             0X10          //设置LED颜色
#define   MoterSpeed_SET                      0x11          //设置电机速度
#define   UlSensorLed_Set                     0x12          //超声波灯光设置
#define   Buzzer_Set                          0x13          //蜂鸣器设置
#define   ExPanel_Set                         0x14          //表情面板设置
#define   LowPorw_Set                         0x15          //低电压主动上报
#define   Button_Set                          0x16          //按键设置
#define   MoterTurs_Set                       0x17          //设置电机圈数
#define   Mode_Change                         0x18          //模式切换
#define   Servo_Set                           0x19          //舵机控制
#define   ExDCMotor_Set                       0x1A          //外置电机控制
#define   RGBLEDMatrix_Set                    0x1B          //RGB矩阵屏设置
#define   MP3_Set                             0x1C          //MP3设置
#define   TouchSensor_Set                     0x1D          //触摸传感器主动上报设置
#define   DigitalDisplay_Set                  0x1E          //4段数码管显示设置
#define   RGBLEDArray_Set                     0x1F          //4个RGBLED显示设置
#define   FAN_Set                             0X20          //设置风扇

#define   UlSensorDistance_Read               0xA1          //超声波距离读取
#define   Button_Read                         0xA2          //按键读取
#define   Power_Read                          0xA3          //读取电压
#define   Line_Follower_Read                  0xA4          //巡线传感器数据读取
#define   Humi_And_Temp_Read                  0xA5          //温湿度传感器数据读取
#define   Light_Read                          0xA6          //光线传感器数据读取
#define   Sound_Read                          0xA7          //声音传感器数据读取
#define   PIRSensor_Read                      0xA8          //人体红外传感器读取
#define   GyroSensor_Read                     0xA9          //陀螺仪传感器数据读取
#define   ColorSensor_Read                    0XAA          //颜色传感器读取
#define   TouchSensor_Read                    0XAB          //触摸传感器读取
#define   TemptureSensors_Read                0XAC          //2路温度传感读取
#define   Line_Follower_Array_Read            0XAD          //6路巡线传感器读取
#define   JoyStickSensor_Read                 0XAE          //遥感读取
#define   FlameSensor_Read                    0XAF          //火焰读取
#define   GasSensor_Read                      0XB0          //气体读取      
#define   Potentimeter_Read                   0XB1          //电位器读取
#define   LinePotentimeter_Read               0XB2          //滑动电位器读取
#define   ChipID_Read                         0XB3          //芯片ChipID读取

#endif
