#ifndef QM_GYRO_H_
#define QM_GYRO_H_

#include <inttypes.h>
#include <Arduino.h>
#include "QM_PORT.h"
#include "QM_SOFTI2CMASTER.h"

#define GYRO_ADDRESS_GND 0X68;
#define GYRO_ADDRESS_VCC 0X69;

class QM_GYRO : public QM_SoftI2CMaster
{
public:
    QM_GYRO(void);
    QM_GYRO(uint8_t port);
    void ReadData(uint8_t start_regaddress, uint8_t *buffer, uint8_t datalen);
    void WriteData(uint8_t start_regaddress, uint8_t *buffer, uint8_t datalen);
    void WriteReg(uint8_t start_regaddress, uint8_t buffer);
    void begin(void);
    void Update(void);
    void FastUpdate(void);
    double getAngleX(void);
    double getAngleY(void);
    double getAngleZ(void);
    double getGyroX(void);
    double getGyroY(void);
    double getGyroZ(void);
    int16_t getAccX(void);
    int16_t getAccY(void);
    int16_t getAccZ(void);

private:
    double gSensitivity;
    double AngleX, AngleY, AngleZ;
    double GyroX, GyroY, GyroZ;
    int16_t AccX, AccY, AccZ;
    double GyroXoffset, GyroYoffset, GyroZoffset;
    uint8_t i2cData[14];
    uint16_t Device_Address;
    void deviceCalibration(void);
};

#endif
