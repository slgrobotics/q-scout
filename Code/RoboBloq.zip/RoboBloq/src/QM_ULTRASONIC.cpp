#include "QM_Ultrasonic.h"
#include "Wire.h"
#include "QM_PORT.h"
#include "time.h"

QM_Port ultrasonic_port;

QM_Ultrasonic::QM_Ultrasonic(void)
{
    ultrasonic_port.GPIO_Init();
}

//QM_Ultrasonic::QM_Ultrasonic(uint8_t port):TwoWire(1)
QM_Ultrasonic::QM_Ultrasonic(uint8_t port)
{
    ultrasonic_port.GPIO_Init();
    ultrasonic_port.Select_Port(port);
    pinMode(_dat, OUTPUT);
    pinMode(_clk, INPUT);
}

double QM_Ultrasonic::distanceCm(uint16_t MAXcm)
{
    long distance = measure(MAXcm * 100 + 200);
    if (distance <= 0)
    {
        distance = MAXcm * 58;
    }
    return ((double)distance / 58.0);
}

double QM_Ultrasonic::distanceInch(uint16_t MAXinch)
{
    long distance = measure(MAXinch * 145 + 200);
    if (distance == 0)
    {
        distance = MAXinch * 148;
    }
    return ((double)(distance / 148.0));
}

long QM_Ultrasonic::measure(unsigned long timeout)
{
    pinMode(SDA0_COM, OUTPUT);
    digitalWrite(SDA0_COM, LOW);
    delayMicroseconds(2);
    digitalWrite(SDA0_COM, HIGH);
    delayMicroseconds(10);
    digitalWrite(SDA0_COM, LOW);

    pinMode(SCL0_COM, INPUT);
    float duration = pulseIn(SCL0_COM, HIGH, timeout);

    delay(10); // 此处必须有延时

    // Serial.print("duration:");
    // Serial.println(duration);

    return (duration);
}

// double QM_Ultrasonic::Uldistance(double max_distance)
// {
//   double  Distance[12];

//   double  total = 0;      // 12个数值中间8个数值的和
//   double  average;
//   uint8_t i=0;
//   for(i=0;i<12;i++)   // 取12个数值
//   {
//     Distance[i] = distanceCm();
//     delay(18);
//   }

//   // 对取到的12个数排序
//   BubbleSort(Distance, 12);

//   // 取中间8个数的总和
//   for(i=2;i<10;i++)
//     total += Distance[i];

//   // 取平均
//   average = total/8;

//   return average;
// }

double QM_Ultrasonic::Uldistance()
{
    double Distance[3];

    double total = 0; // 3个数值中间1个数值的和
    double average;
    uint8_t i = 0;
    for (i = 0; i < 3; i++) // 取3个数值
    {
        Distance[i] = distanceCm();
        // delay(18);
    }

    // 对取到的3个数排序
    BubbleSort(Distance, 3);

    return Distance[1];
}


double QM_Ultrasonic::Uldistance(uint8_t port)
{
    ultrasonic_port.Select_Port(port);
    double Distance[3];

    double total = 0; // 3个数值中间1个数值的和
    double average;
    uint8_t i = 0;
    for (i = 0; i < 3; i++) // 取3个数值
    {
        Distance[i] = distanceCm();
        // delay(18);
    }

    // 对取到的3个数排序
    BubbleSort(Distance, 3);

    return Distance[1];
}
void QM_Ultrasonic::Swap(double A[], int i, int j)
{
    double temp = A[i];
    A[i] = A[j];
    A[j] = temp;
}

void QM_Ultrasonic::BubbleSort(double A[], int n)
{
    for (int j = 0; j < n - 1; j++) // 每次最大元素就像气泡一样"浮"到数组的最后
    {
        for (int i = 0; i < n - 1 - j; i++) // 依次比较相邻的两个元素,使较大的那个向后移
        {
            if (A[i] > A[i + 1]) // 如果条件改成A[i] >= A[i + 1],则变为不稳定的排序算法
            {
                Swap(A, i, i + 1);
            }
        }
    }
}
