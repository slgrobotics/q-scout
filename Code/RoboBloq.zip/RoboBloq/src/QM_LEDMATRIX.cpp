#include "QM_LEDMATRIX.h"
// #include "Wire.h"
#include "QM_PORT.h"

QM_Port            LEDMatrix_port;
// TwoWire            *led_matrix_iic_bus          = NULL;

#if 0

QM_LEDMatrix::QM_LEDMatrix(void) : QM_SoftI2CMaster(port)
{
    LEDMatrix_port.GPIO_Init();

    // if(led_matrix_iic_bus == NULL){
    //     led_matrix_iic_bus = new TwoWire(1);
    // }
    // led_matrix_iic_bus->setPins(SDA0_COM,SCL0_COM);
    // led_matrix_iic_bus->begin();

    QM_SoftI2CMaster::SetMode(1);
}
#endif


QM_LEDMatrix::QM_LEDMatrix(uint8_t port) : QM_SoftI2CMaster(port)
{ 
    LEDMatrix_port.GPIO_Init();
    LEDMatrix_port.Select_Port(port);

    // if(led_matrix_iic_bus == NULL){
    //     led_matrix_iic_bus = new TwoWire(1);
    // }
    // led_matrix_iic_bus->begin(SDA0_COM,SCL0_COM,20000);

    // led_matrix_iic_bus->beginTransmission(TM1680ID);
    // led_matrix_iic_bus->write(SYSDIS);
    // led_matrix_iic_bus->write(COM16NMOS);
    // led_matrix_iic_bus->write(RCMODE1);
    // led_matrix_iic_bus->write(SYSEN);
    // led_matrix_iic_bus->write(LEDON);
    // led_matrix_iic_bus->endTransmission();

    QM_SoftI2CMaster::SetMode(1);

    Serial.println("SetMode:1");
 
    I2C_Star();
    Serial.println("I2C_Star");
    send(TM1680ID);   //  0xE7
    Serial.println("send address");
    send(SYSDIS);  
    send(COM16NMOS);   //根据需求进行选择  COM8NMOS
    send(RCMODE1); 
    send(SYSEN);  
    send(LEDON); 
    I2C_Stop(); 
}



/***
    函数功能：页操作
***/
void QM_LEDMatrix:: QM_LEDMatrix_PageWrite(unsigned char faddr, unsigned char pdate[20]) 
{
    unsigned char  i=0,j=19,k=0;
    unsigned short ussdata =0 ;
    unsigned char  outdata[20];
    unsigned char  data;

    Serial.println("PageWrite");

    for(i=0; i<10; i++)
   {    
        ussdata = (unsigned short)pdate[2*i]<<8|pdate[2*i+1];
        ussdata = ((ussdata & 0xAAAA) >> 1) | ((ussdata & 0x5555) << 1);  
        ussdata = ((ussdata & 0xCCCC) >> 2) | ((ussdata & 0x3333) << 2);  
        ussdata = ((ussdata & 0xF0F0) >> 4) | ((ussdata & 0x0F0F) << 4);  
        ussdata = ((ussdata & 0xFF00) >> 8) | ((ussdata & 0x00FF) << 8);  
        
        ussdata = ussdata<<2;
        outdata[j--] = (unsigned char)(ussdata&0xff);
        outdata[j--]  = (unsigned char )((ussdata&0xff00)>>8);  
        
    }

    I2C_Star();
    
    send(TM1680ID);  //写TM1680器件地址
    send(faddr);  //eeprom 地址

    // led_matrix_iic_bus->beginTransmission(TM1680ID);
    // led_matrix_iic_bus->write(faddr);
   
    for(k=0; k<20; k++)
    {    
      data  = outdata[k];
      data=((data&0xCC)>>2) | ((data&0x33)<<2); 
      data=((data&0xAA)>>1) | ((data&0x55)<<1);   
      send(data);  //写     

    //   led_matrix_iic_bus->write(data);  
    }
    
    I2C_Stop();

    // led_matrix_iic_bus->endTransmission();
}


void QM_LEDMatrix:: QM_LEDMatrix_PageWrite(uint8_t port, unsigned char faddr, unsigned char pdate[20]) 
{
    LEDMatrix_port.Select_Port(port);
    unsigned char  i=0,j=19,k=0;
    unsigned short ussdata =0 ;
    unsigned char  outdata[20];
    unsigned char  data;

    Serial.println("PageWrite");

    for(i=0; i<10; i++)
   {    
        ussdata = (unsigned short)pdate[2*i]<<8|pdate[2*i+1];
        ussdata = ((ussdata & 0xAAAA) >> 1) | ((ussdata & 0x5555) << 1);  
        ussdata = ((ussdata & 0xCCCC) >> 2) | ((ussdata & 0x3333) << 2);  
        ussdata = ((ussdata & 0xF0F0) >> 4) | ((ussdata & 0x0F0F) << 4);  
        ussdata = ((ussdata & 0xFF00) >> 8) | ((ussdata & 0x00FF) << 8);  
        
        ussdata = ussdata<<2;
        outdata[j--] = (unsigned char)(ussdata&0xff);
        outdata[j--]  = (unsigned char )((ussdata&0xff00)>>8);  
        
    }

    I2C_Star();
    
    send(TM1680ID);  //写TM1680器件地址
    send(faddr);  //eeprom 地址

    for(k=0; k<20; k++)
    {    
      data  = outdata[k];
      data=((data&0xCC)>>2) | ((data&0x33)<<2); 
      data=((data&0xAA)>>1) | ((data&0x55)<<1);   
      send(data);  //写     

    }
    
    I2C_Stop();
}

void QM_LEDMatrix::QM_LEDMatrix_PageAllWrite(unsigned char faddr,unsigned char sdate,unsigned char cnt)
{
    unsigned char i=0;
    unsigned char date=0;

    Serial.println("PageAllWrite");
    I2C_Star();
    
    send(TM1680ID);  
    send(faddr);  //eeprom 地址

    for(i=0; i<cnt; i++)
    {       
        send(sdate);  //写     
    }
    I2C_Stop();
} 

void QM_LEDMatrix::QM_LEDMatrix_PageAllWrite(uint8_t port, unsigned char faddr,unsigned char sdate,unsigned char cnt)
{
    LEDMatrix_port.Select_Port(port);
    unsigned char i=0;
    unsigned char date=0;

    Serial.println("PageAllWrite");
    I2C_Star();
    
    send(TM1680ID);  
    send(faddr);  //eeprom 地址

    for(i=0; i<cnt; i++)
    {       
        send(sdate);  //写     
    }
    I2C_Stop();
}