#ifndef  _QM_Port_H
#define  _QM_Port_H


#include <Arduino.h>
#include <stdint.h>
#include <stdlib.h>



/****************SYSTEM DEFINE START  ********************/

#define   RB_PORT_USER_DEFINED 
#define   Other_Device                   0xff
#define   None_Device                    0x00
#define   Encode_Motor_Divice            0x01
#define   Ultrasonic_Distance_Sensor     0x02
#define   LED_Matraix_Blue               0x03
#define   Line_Follower_Sensor           0x04
#define   Servo_Device                   0x05
#define   Temp_And_Humi_Sensor           0x06
#define   Light_Sensor                   0x07
#define   Sound_Sensor                   0x08
#define   DC_Motor_Device                0x09
#define   PIR_Sensor                     0x0A
#define   MP3_Sensor                     0X0B
#define   RGBLED_Matraix                 0X0C
#define   Color_Sensor                   0X0D
#define   Gyro_Sensor                    0X0E
#define   Touch_Sensor                   0X0F  
#define   Tempture_Sensors               0X10
#define   Line_Follower_Array_Sensors    0X11
#define   DigitalDisplay_Device          0X12 
#define   RGBLED_Array_Device            0X13
#define   JoyStick_Sensor                0X14  
#define   Flame_Sensor                   0X15
#define   Gas_Sensor                     0X16
#define   Potentimeter_Sensor            0X17 
#define   Line_Potentimeter_Sensor       0X18
#define   Fan_Divice                     0X19
#define   IR_Remote_Sensor               0X20

/*****************SYSTEM DEFINE END****************************/


    


typedef struct 
{
   uint8_t  port_A;
   uint8_t  port_B;
   uint8_t  pwm_A;
   uint8_t  pwm_B; 
} RB_Port_Encoder;



#define NC             0

#define ENA_A          39
#define ENA_B          36
#define ENB_A          32
#define ENB_B          35
#define moter_sleep    33
#define VBAT_Pin       33
#define RGB_LED_Pin    25
#define Buzzer_Pin     26
#define USER_KEY_Pin   34

#define motor_BIN1     27
#define motor_BIN2     14
#define motor_AIN1     12 
#define motor_AIN2     13	
#define APC            15

#define IR_Send        2
#define IR_Rev         4

#define ADC_Pin        4

#define SCL0_COM       5
#define SDA0_COM       18

#define BLE_LED_Pin    19

#define SEL_I2C_C      21
#define SEL_I2C_B      22
#define SEL_I2C_A      23

#define TXD            3
#define RXD            1

#define _clk SCL0_COM
#define _dat SDA0_COM
#define SAMPLE_TIMES   5  

class QM_Port 
{
    public :
        QM_Port(void);
        QM_Port(uint8_t port);
        void GPIO_Init(void);
        void Select_Port(uint8_t port);
        uint8_t GetPort(void); 
        uint8_t GetPortSensrType(uint8_t port);  
        bool DReadClk(void);
        bool DReadDat(void);
        void DWriteClk(bool value);
        void DWriteDat(bool value );
        int16_t AReadClk(void);
        int16_t AReadDat(void);
    protected:
        uint8_t  _port;
        void   Swap(int A[], int i, int j);
        void   BubbleSort(int A[], int n);
            
} ; 

#endif 
