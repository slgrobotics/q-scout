
#include "QM_QMINDX.h"
/*
 * 
 */
QM_Port::QM_Port(void)
{
   _port = 0 ;
}
/*
 * 
 */
QM_Port::QM_Port(uint8_t port)
{
   _port = port ;
   GPIO_Init();
   Select_Port(_port);
}



void QM_Port::GPIO_Init(void)
{
  pinMode(SEL_I2C_C, OUTPUT);    // SEL_I2C_C
  pinMode(SEL_I2C_B, OUTPUT);    // SEL_I2C_B
  pinMode(SEL_I2C_A, OUTPUT);    // SEL_I2C_A
  
  pinMode(BLE_LED_Pin, OUTPUT);          // LED: Connect Status

  pinMode(USER_KEY_Pin, INPUT);  // User Key

  pinMode(motor_BIN1, OUTPUT);   // motor_BIN1
  pinMode(motor_BIN2, OUTPUT);   // motor_BIN2

  pinMode(motor_AIN1, OUTPUT);   // motor_AIN1
  pinMode(motor_AIN2, OUTPUT);   // motor_AIN2

//   pinMode(moter_sleep, OUTPUT);  // motor_sleep

  pinMode(APC, INPUT);
}



void QM_Port::Select_Port(uint8_t port)
{
//   printf("port No: %d\n",port);
  switch(port)
  {
    case 1:  
      digitalWrite(SEL_I2C_C,HIGH);
      digitalWrite(SEL_I2C_B,LOW);
      digitalWrite(SEL_I2C_A,LOW);
      break;
    case 2:
      digitalWrite(SEL_I2C_C,HIGH);
      digitalWrite(SEL_I2C_B,LOW);
      digitalWrite(SEL_I2C_A,HIGH);
      break;
#if MachineType == 1  // K1
    case 3:
      digitalWrite(SEL_I2C_C,HIGH);
      digitalWrite(SEL_I2C_B,HIGH);
      digitalWrite(SEL_I2C_A,LOW);
      break;
    case 4:
      digitalWrite(SEL_I2C_C,HIGH);
      digitalWrite(SEL_I2C_B,HIGH);
      digitalWrite(SEL_I2C_A,HIGH);
      break;
    case 5:
      digitalWrite(SEL_I2C_C,LOW);
      digitalWrite(SEL_I2C_B,HIGH);
      digitalWrite(SEL_I2C_A,HIGH);
      break;
    case 6:
      digitalWrite(SEL_I2C_C,LOW);
      digitalWrite(SEL_I2C_B,HIGH);
      digitalWrite(SEL_I2C_A,LOW);
      break;
    case 7:
      digitalWrite(SEL_I2C_C,LOW);
      digitalWrite(SEL_I2C_B,LOW);
      digitalWrite(SEL_I2C_A,HIGH);
      break;
    case 8:
      digitalWrite(SEL_I2C_C,LOW);
      digitalWrite(SEL_I2C_B,LOW);
      digitalWrite(SEL_I2C_A,LOW);
      break;
#elif MachineType == 2
    case 3:
      digitalWrite(SEL_I2C_C,LOW);
      digitalWrite(SEL_I2C_B,LOW);
      digitalWrite(SEL_I2C_A,HIGH);
      break;
    case 4:
      digitalWrite(SEL_I2C_C,LOW);
      digitalWrite(SEL_I2C_B,LOW);
      digitalWrite(SEL_I2C_A,LOW);
      break;
#endif    
    default:
      break;
  }
  delay(10); // 此处必须有延时
}
/*
 * 
 */
uint8_t QM_Port :: GetPort(void)
{
   return(_port);
}

// volatile int Positive_pulse_width = 0;
// volatile int Negative_pulse_width = 0;
// volatile int Duty_cycle = 0;
int Positive_pulse_width = 0;
int Negative_pulse_width = 0;
int Duty_cycle = 0;


int Pos_width[SAMPLE_TIMES];
int Neg_width[SAMPLE_TIMES];

uint8_t QM_Port :: GetPortSensrType(uint8_t port)
{
    uint8_t j;

    Positive_pulse_width = 0;
    Negative_pulse_width = 0;
    Duty_cycle = 0;

    Select_Port(port);
    delay(10);

    for(j=0;j<SAMPLE_TIMES;j++){
        Pos_width[j] = pulseIn(15, HIGH, 20000);  // GP9101-F100 超时时间：20ms  2个周期 此参数不可调小
        // Pos_width[j] = pulseIn(15, HIGH, 4000);  // GP9101-F1K 超时时间：4ms  2个周期 此参数不可调小
        // printf("%d Pos_width = %d \n", j, Pos_width[j]);
        // Positive_pulse_width += Pos_width;
        Neg_width[j] = pulseIn(15, LOW, 20000);   // GP9101-F100 超时时间：20ms  2个周期 此参数不可调小
        // Neg_width[j] = pulseIn(15, LOW, 4000);   // GP9101-F1K 超时时间：4ms  2个周期 此参数不可调小
        // printf("%d Neg_width = %d \n", j, Neg_width[j]);
        // Negative_pulse_width += Neg_width;
    }
      
    // 对取到的SAMPLE_TIMES个数排序
    BubbleSort(Pos_width, SAMPLE_TIMES);
    BubbleSort(Neg_width, SAMPLE_TIMES);

    // for(j=0;j<SAMPLE_TIMES;j++){
    //     printf("%d Pos_width = %d \n", j, Pos_width[j]);
    //     printf("%d Neg_width = %d \n", j, Neg_width[j]);
    // }
    // 取中间数的总和
    for (j = 2; j < SAMPLE_TIMES-2; j++){
        Positive_pulse_width += Pos_width[j];
        Negative_pulse_width += Neg_width[j];
    }
    Positive_pulse_width /= SAMPLE_TIMES - 4;
    // printf("Positive_pulse_width = %d \n", Positive_pulse_width);
    Negative_pulse_width /= SAMPLE_TIMES - 4;
    // printf("Negative_pulse_width = %d \n", Negative_pulse_width);

    if((Negative_pulse_width + Positive_pulse_width) != 0)   // 必须计算占空比，仅凭脉宽不准确
        Duty_cycle = (Positive_pulse_width * 10000) / (Negative_pulse_width + Positive_pulse_width);

    if(Duty_cycle < 1181)
        return None_Device;
    else if((1181 < Duty_cycle) && (Duty_cycle < 1601))
        return Line_Potentimeter_Sensor;
    else if((1601 < Duty_cycle) && (Duty_cycle < 2118))
        return Fan_Divice;
    else if((2118 < Duty_cycle) && (Duty_cycle < 2518))
        return Line_Follower_Sensor;
    else if((2626 < Duty_cycle) && (Duty_cycle < 3026))
        return Temp_And_Humi_Sensor;
    else if((3100 < Duty_cycle) && (Duty_cycle < 3500))
        return DigitalDisplay_Device;
    else if((3566 < Duty_cycle) && (Duty_cycle < 3966))
        return Light_Sensor;
    else if((4320 < Duty_cycle) && (Duty_cycle < 4720))
        return Line_Follower_Array_Sensors;
    else if((4788 < Duty_cycle) && (Duty_cycle < 5188))
        return LED_Matraix_Blue;
    else if((5208 < Duty_cycle) && (Duty_cycle < 5608))
        return Sound_Sensor;
    else if((5665 < Duty_cycle) && (Duty_cycle < 5962))
        return Gyro_Sensor;
    else if((5962 < Duty_cycle) && (Duty_cycle < 6162))
        return IR_Remote_Sensor;
    else if((6523 < Duty_cycle) && (Duty_cycle < 6923))
        return Ultrasonic_Distance_Sensor;
    else if((7034 < Duty_cycle) && (Duty_cycle < 7434))
        return Color_Sensor;
    else if((7326 < Duty_cycle) && (Duty_cycle < 7726))
        return MP3_Sensor;
    else if((8710 < Duty_cycle) && (Duty_cycle < 9110))
        return PIR_Sensor;
    else if((9340 < Duty_cycle) && (Duty_cycle < 9560))
        return RGBLED_Array_Device;
    else if((9560 < Duty_cycle) && (Duty_cycle < 9784))
        return Touch_Sensor;
    else 
        return 0;   
}

/*
 *  读取数字clk 端口数据
 */
bool QM_Port::DReadClk(void)
{
    bool val;
    pinMode(_clk,INPUT_PULLUP);
    val = digitalRead(_clk);
    return(val);   
}
/*
 * 
 */
bool QM_Port::DReadDat(void)
{  
   bool val ;
   pinMode(_dat,INPUT_PULLUP);
   val = digitalRead(_dat);
   return(val); 
}
/*
 * 
 */
void QM_Port::DWriteClk(bool value)
{  
   pinMode(_clk,OUTPUT);
   digitalWrite(_clk,value);     
}
/*
 * 
 */
 void QM_Port::DWriteDat(bool value )
 {
   pinMode(_dat,OUTPUT);
   digitalWrite(_dat,value);
 }

/*
 * 
 */
int16_t QM_Port::AReadClk(void)
{
  int16_t val;
  pinMode(_clk, INPUT);
  val = analogRead(_clk);
  return(val); 
}
/*
 * 
 */
int16_t QM_Port::AReadDat(void)
{
  int16_t val;
  pinMode(_dat, INPUT);
  val = analogRead(_dat); 
  return(val);  
}


void  QM_Port:: Swap(int A[], int i, int j)
{
    int temp = A[i];
    A[i] = A[j];
    A[j] = temp;
}

void QM_Port:: BubbleSort(int A[], int n)
{
    for (int j = 0; j < n - 1; j++)         // 每次最大元素就像气泡一样"浮"到数组的最后
    {
        for (int i = 0; i < n - 1 - j; i++) // 依次比较相邻的两个元素,使较大的那个向后移
        {
            if (A[i] > A[i + 1])            // 如果条件改成A[i] >= A[i + 1],则变为不稳定的排序算法
            {
                Swap(A, i, i + 1);
            }
        }
    }
}


