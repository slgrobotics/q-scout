#ifndef QM_GYROSCOPES_H_
#define QM_GYROSCOPES_H_

#include <inttypes.h>
#include <Arduino.h>
#include "QM_PORT.h"
#include "QM_SOFTI2CMASTER.h"

#define GYRO_ADDRESS_GND 0X68;
#define GYRO_ADDRESS_VCC 0X69;

class QM_GYROSCOPES : public QM_SoftI2CMaster
{
public:
    QM_GYROSCOPES(void);
    QM_GYROSCOPES(uint8_t port);

    void begin(void);
    void begin(uint8_t port);
    void Update(void);
    double getAngleX(void);
    double getAngleY(void);
    double getAngleZ(void);
    double getGyroX(void);
    double getGyroY(void);
    double getGyroZ(void);
    int16_t getAccX(void);
    int16_t getAccY(void);
    int16_t getAccZ(void);

    double getAngleX(uint8_t port);
    double getAngleY(uint8_t port);
    double getAngleZ(uint8_t port);
    double getGyroX(uint8_t port);
    double getGyroY(uint8_t port);
    double getGyroZ(uint8_t port);
    int16_t getAccX(uint8_t port);
    int16_t getAccY(uint8_t port);
    int16_t getAccZ(uint8_t port);

private:
    uint8_t Device_ID;
};

#endif
