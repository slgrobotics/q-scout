#ifndef QM_RGBLEDMOUDLE_H_
#define QM_RGBLEDMOUDLE_H_

#include <inttypes.h>
#include <Arduino.h>
#include "QM_PORT.h"

#define QM_MAX_LED_NUMBER (100)
#define LED_MOUDLE_Pin 18

class QM_RGBLedMoudle : public QM_Port
{
public:
    /*
        * 
        */
    QM_RGBLedMoudle(uint8_t port);
    /*
        * 
        */
    QM_RGBLedMoudle(uint8_t port, uint8_t led_number);
    /*
        * 
        */
    ~QM_RGBLedMoudle(void);
    /*
        * 
        */
    bool setColorAt(uint8_t index, uint8_t red, uint8_t green, uint8_t blue);
    /*
          * 
          */
    bool setColor(uint8_t red, uint8_t green, uint8_t blue);
    /*    
         *     
         */
    bool setColor(uint8_t index, uint8_t red, uint8_t green, uint8_t blue);
    /*
         * 
         */
    void show(void);

private:
    uint16_t count_led;
};

#endif
