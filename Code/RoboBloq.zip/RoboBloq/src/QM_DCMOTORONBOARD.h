#ifndef QM_DcmotorOnBoard_H
#define QM_DcmotorOnBoard_H

#include <stdint.h>
#include <stdbool.h>
#include <Arduino.h>
#include "QM_PORT.h"
#include "ESP32MotorControl.h"

class QM_DcmotorOnBoard
{
public:
    void QM_DcmotorOnBoard_Init();
    void QM_DcmotorOnBoardM1_Run(int32_t speed);
    void QM_DcmotorOnBoardM2_Run(int32_t speed);
    void run(int32_t speed1, int32_t speed2);
    void stop(void);

private:
    int32_t _M2_Speed;
    int32_t _M1_Speed;
};

#endif
