#ifndef QM_SoundSensor_H
#define QM_SoundSensor_H

#include <stdint.h>
#include <stdbool.h>
#include <Arduino.h>

#include "QM_PORT.h"

class QM_SoundSensor : public QM_Port
{
public:
    QM_SoundSensor(void);
    QM_SoundSensor(uint8_t port);
    uint16_t GetSound(void);
    uint16_t GetSoundValue(void);
    uint16_t GetSoundValue(uint8_t port);

private:
    uint8_t _SigPin;
};

#endif
