#include "QM_PIRSENSOR.h"

QM_Port pirsensor_port;

QM_PirSensor::QM_PirSensor(void)
{
    pirsensor_port.GPIO_Init();
}

QM_PirSensor::QM_PirSensor(uint8_t port)
{
    pirsensor_port.GPIO_Init();
    pirsensor_port.Select_Port(port);
    _SigPin = _dat;
    _ModePin = _clk;
    pinMode(_SigPin, INPUT);
    pinMode(_ModePin, OUTPUT);
    digitalWrite(_ModePin, LOW);
}

void QM_PirSensor::SetPin(uint8_t sigpin, uint8_t modepin)
{
    _SigPin = sigpin;
    _ModePin = modepin;
    pinMode(_SigPin, INPUT);
    pinMode(_ModePin, OUTPUT);
    digitalWrite(_ModePin, LOW);
}
void QM_PirSensor::SetPirMode(uint8_t Mode)
{

    digitalWrite(_ModePin, Mode);
}

uint8_t QM_PirSensor::GetPirSensor(void)
{
    _SigPin = _dat;
    _ModePin = _clk;
    pinMode(_SigPin, INPUT);
    pinMode(_ModePin, OUTPUT);
    digitalWrite(_ModePin, LOW);

    if ((digitalRead(_SigPin) == 0))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

uint8_t QM_PirSensor::GetPirSensor(uint8_t port)
{
    pirsensor_port.Select_Port(port);

    _SigPin = _dat;
    _ModePin = _clk;
    pinMode(_SigPin, INPUT);
    pinMode(_ModePin, OUTPUT);
    digitalWrite(_ModePin, LOW);

    if ((digitalRead(_SigPin) == 0))
    {
        return 1;
    }
    else
    {
        return 0;
    }  
}