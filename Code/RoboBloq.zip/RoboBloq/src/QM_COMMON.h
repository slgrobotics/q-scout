#ifndef _QM_COMMON_H
#define _QM_COMMON_H

#include "QM_QMINDX.h"


void PrintBoardInfor(void)
{
    Serial.println("   ");
#if MachineType == 1 // K1
    Serial.println("QmindX V4.0.1");
#elif MachineType == 2 // K2
    Serial.println("QmindX V3.0.1");
#endif
}

#endif
