#ifndef QM_RGBLEDONBOARD_H_
#define QM_RGBLEDONBOARD_H_

#include <inttypes.h>
#include <Arduino.h>
#include "QM_PORT.h"

struct QM_RGB
{
    uint8_t g;
    uint8_t r;
    uint8_t b;
};

class QM_RGBLed : public QM_Port
{
public:
    /*
        * 
        */
    QM_RGBLed(uint8_t port);
    /*
        * 
        */
    QM_RGBLed(uint8_t port, uint8_t led_number);
    /*
        * 
        */
    ~QM_RGBLed(void);
    /*
        * 
        */
    bool setColorAt(uint8_t index, uint8_t red, uint8_t green, uint8_t blue);
    /*
          * 
          */
    bool setColor(uint8_t red, uint8_t green, uint8_t blue);
    /*    
         *     
         */
    bool setColor(uint8_t index, uint8_t red, uint8_t green, uint8_t blue);
    /*
         * 
         */
    void show(void);

private:
    uint16_t count_led;
};

#endif
