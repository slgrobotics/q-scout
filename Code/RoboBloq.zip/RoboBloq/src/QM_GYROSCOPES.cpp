#include "QM_GYROSCOPES.h"
#include "QM_GYRO.h"
#include "QM_ICM42605.h"
#include <string.h>

QM_GYRO      *gyro = NULL;
QM_ICM42605  *icm42605 = NULL;
QM_Port gyroscopes_port;

QM_GYROSCOPES::QM_GYROSCOPES(void):QM_SoftI2CMaster(0)
{
	QM_SoftI2CMaster::SetMode(1);
}


QM_GYROSCOPES::QM_GYROSCOPES(uint8_t port):QM_SoftI2CMaster(port)
{
    gyroscopes_port.GPIO_Init();
    gyroscopes_port.Select_Port(port);
    if(gyro == NULL){
        gyro = new QM_GYRO(port);
    }

    if(icm42605 == NULL){
        icm42605 = new QM_ICM42605(port);
    }
}



void QM_GYROSCOPES::begin(void)
{
    gyro->ReadData(0x75,&Device_ID,1);
    // Serial.print("Who am I:");
    // Serial.println(Device_ID);

    if(Device_ID == 0x20){
        icm42605->begin();
    }
    else if(Device_ID == 0x68){
        gyro->begin();
    }
    else
        Serial.println("Device ID error!");
}

void QM_GYROSCOPES::begin(uint8_t port)
{
    gyroscopes_port.Select_Port(port);
    gyro->ReadData(0x75,&Device_ID,1);
    // Serial.print("Who am I:");
    // Serial.println(Device_ID);

    if(Device_ID == 0x20){
        icm42605->begin();
    }
    else if(Device_ID == 0x68){
        gyro->begin();
    }
    else
        Serial.println("Device ID error!");
}

void QM_GYROSCOPES::Update(void)
{
    if(Device_ID == 0x20){
        icm42605->Update();
    }
    else if(Device_ID == 0x68){
        gyro->Update();
    }
}



double QM_GYROSCOPES::getAngleX(void)
{
    Update();

    if(Device_ID == 0x20){
        return icm42605->getAngleX();
    }
    else if(Device_ID == 0x68){
        return gyro->getAngleX();
    }
    else
        return -1;
}
double QM_GYROSCOPES::getAngleX(uint8_t port)
{
    gyroscopes_port.Select_Port(port);
    Update();

    if(Device_ID == 0x20){
        return icm42605->getAngleX();
    }
    else if(Device_ID == 0x68){
        return gyro->getAngleX();
    }
    else
        return -1;
}

double QM_GYROSCOPES::getAngleY(void)
{
    Update();

    if(Device_ID == 0x20){
        return icm42605->getAngleY();
    }
    else if(Device_ID == 0x68){
        return gyro->getAngleY();
    }
    else
        return -1;
}
double QM_GYROSCOPES::getAngleY(uint8_t port)
{
    gyroscopes_port.Select_Port(port);
    Update();

    if(Device_ID == 0x20){
        return icm42605->getAngleY();
    }
    else if(Device_ID == 0x68){
        return gyro->getAngleY();
    }
    else
        return -1;
}

double QM_GYROSCOPES::getAngleZ(void)
{
    Update();

    if(Device_ID == 0x20){
        return icm42605->getAngleZ();
    }
    else if(Device_ID == 0x68){
        return gyro->getAngleZ();
    }
    else
        return -1;
}
double QM_GYROSCOPES::getAngleZ(uint8_t port)
{
    gyroscopes_port.Select_Port(port);
    Update();

    if(Device_ID == 0x20){
        return icm42605->getAngleZ();
    }
    else if(Device_ID == 0x68){
        return gyro->getAngleZ();
    }
    else
        return -1;
}

double QM_GYROSCOPES::getGyroX(void)
{
    Update();

    if(Device_ID == 0x20){
        return icm42605->getGyroX();
    }
    else if(Device_ID == 0x68){
        return gyro->getGyroX();
    }
    else
        return -1;
}
double QM_GYROSCOPES::getGyroX(uint8_t port)
{
    gyroscopes_port.Select_Port(port);
    Update();

    if(Device_ID == 0x20){
        return icm42605->getGyroX();
    }
    else if(Device_ID == 0x68){
        return gyro->getGyroX();
    }
    else
        return -1;
}

double QM_GYROSCOPES::getGyroY(void)
{
    Update();

    if(Device_ID == 0x20){
        return icm42605->getGyroY();
    }
    else if(Device_ID == 0x68){
        return gyro->getGyroY();
    }
    else 
        return -1;
}
double QM_GYROSCOPES::getGyroY(uint8_t port)
{
    gyroscopes_port.Select_Port(port);
    Update();

    if(Device_ID == 0x20){
        return icm42605->getGyroY();
    }
    else if(Device_ID == 0x68){
        return gyro->getGyroY();
    }
    else 
        return -1;
}

double QM_GYROSCOPES::getGyroZ(void)
{   
    Update();

    if(Device_ID == 0x20){
        return icm42605->getGyroZ();
    }
    else if(Device_ID == 0x68){
        return gyro->getGyroZ();
    }
    else
        return -1;
}
double QM_GYROSCOPES::getGyroZ(uint8_t port)
{   
    gyroscopes_port.Select_Port(port);
    Update();

    if(Device_ID == 0x20){
        return icm42605->getGyroZ();
    }
    else if(Device_ID == 0x68){
        return gyro->getGyroZ();
    }
    else
        return -1;
}

int16_t QM_GYROSCOPES::getAccX(void)
{
    Update();

    if(Device_ID == 0x20){
        return icm42605->getAccX();
    }
    else if(Device_ID == 0x68){
        return gyro->getAccX();
    }
    else
        return -1;
}
int16_t QM_GYROSCOPES::getAccX(uint8_t port)
{
    gyroscopes_port.Select_Port(port);
    Update();

    if(Device_ID == 0x20){
        return icm42605->getAccX();
    }
    else if(Device_ID == 0x68){
        return gyro->getAccX();
    }
    else
        return -1;
}

int16_t QM_GYROSCOPES::getAccY(void)
{
    Update();

    if(Device_ID == 0x20){
        return icm42605->getAccY();
    }
    else if(Device_ID == 0x68){
        return gyro->getAccY();
    }
    else
        return -1;
}
int16_t QM_GYROSCOPES::getAccY(uint8_t port)
{
    gyroscopes_port.Select_Port(port);
    Update();

    if(Device_ID == 0x20){
        return icm42605->getAccY();
    }
    else if(Device_ID == 0x68){
        return gyro->getAccY();
    }
    else
        return -1;
}

int16_t QM_GYROSCOPES::getAccZ(void)
{
    Update();

    if(Device_ID == 0x20){
        return icm42605->getAccZ();
    }
    else if(Device_ID == 0x68){
        return gyro->getAccZ();
    }
    else
        return -1;
}
int16_t QM_GYROSCOPES::getAccZ(uint8_t port)
{
    gyroscopes_port.Select_Port(port);
    Update();

    if(Device_ID == 0x20){
        return icm42605->getAccZ();
    }
    else if(Device_ID == 0x68){
        return gyro->getAccZ();
    }
    else
        return -1;
}