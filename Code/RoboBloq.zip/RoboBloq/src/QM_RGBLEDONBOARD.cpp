#include "QM_RGBLEDONBOARD.h"
#include "Adafruit_NeoPixel.h"

Adafruit_NeoPixel rgb_display_25 = Adafruit_NeoPixel(2, 25, NEO_GRB + NEO_KHZ800);
QM_Port RGBLed_port;

uint8_t RGB_LED_OnBoard_Flag = 1; //  1---On Board  0---Outside

uint32_t Wheel(byte WheelPos)
{
    if (WheelPos < 85)
    {
        return rgb_display_25.Color(WheelPos * 3, 255 - WheelPos * 3, 0);
    }
    else if (WheelPos < 170)
    {
        WheelPos -= 85;
        return rgb_display_25.Color(255 - WheelPos * 3, 0, WheelPos * 3);
    }
    else
    {
        WheelPos -= 170;
        return rgb_display_25.Color(0, WheelPos * 3, 255 - WheelPos * 3);
    }
}

//函数功能：实现RGB LED七彩变幻渐变效果
//入口参数：渐变延迟时间，调整渐变速度
void rainbow(uint8_t wait)
{
    uint16_t i, j;
    for (j = 0; j < 256; j++)
    {
        for (i = 0; i < rgb_display_25.numPixels(); i++)
        {
            rgb_display_25.setPixelColor(i, Wheel((i + j) & 255));
        }
        rgb_display_25.show();

        delay(wait);
    }
}

/*
 * 
 */
QM_RGBLed ::QM_RGBLed(uint8_t port, uint8_t led_number)
{
    count_led = led_number;
    RGBLed_port.GPIO_Init();
    // printf("port No: %d\n",port);
    RGB_LED_OnBoard_Flag = 1;
    rgb_display_25.begin();
    rgb_display_25.setBrightness(50);
}

/*
  * 
  */
QM_RGBLed ::~QM_RGBLed(void)
{
}

bool QM_RGBLed::setColor(uint8_t index, uint8_t red, uint8_t green, uint8_t blue)
{
    if (index == 0)
    {
        for (int16_t i = 0; i < count_led; i++)
        {
            rgb_display_25.setPixelColor(i, ((red & 0xffffff) << 16) | ((green & 0xffffff) << 8) | blue);
        }
        return (true);
    }
    else
    {
        rgb_display_25.setPixelColor(index - 1, ((red & 0xffffff) << 16) | ((green & 0xffffff) << 8) | blue);
    }
    return (false);
}

bool QM_RGBLed::setColor(uint8_t red, uint8_t green, uint8_t blue)
{
    return (setColor(0, red, green, blue));
}

void QM_RGBLed::show(void)
{
    rgb_display_25.show();
    delay(1);
}
