#include "QM_LINEFOLLOWER.h"

QM_LineFollower::QM_LineFollower(void) : QM_Port(0)
{
}

QM_LineFollower::QM_LineFollower(uint8_t port) : QM_Port(port)
{
    QM_Port::Select_Port(port);
    pinMode(_dat, INPUT);
    pinMode(_clk, INPUT);
}

uint8_t QM_LineFollower::ReadSensors(void)
{
    uint8_t state = S1_IN_S2_IN;

    pinMode(_dat, INPUT_PULLUP);
    pinMode(_clk, INPUT_PULLUP);

    bool s1State = digitalRead(_dat);
    bool s2State = digitalRead(_clk);
    state = ((1 & s1State) << 1) | s2State;
    return (state);
}

uint8_t QM_LineFollower::ReadSensors(uint8_t port)
{
    QM_Port::Select_Port(port);
    pinMode(_dat, INPUT);
    uint8_t state = S1_IN_S2_IN;

    pinMode(_dat, INPUT_PULLUP);
    pinMode(_clk, INPUT_PULLUP);

    bool s1State = digitalRead(_dat);
    bool s2State = digitalRead(_clk);
    state = ((1 & s1State) << 1) | s2State;
    return (state);
}

bool QM_LineFollower::ReadSensor1(void)
{
    return (digitalRead(_dat));
}

bool QM_LineFollower::ReadSensor1(uint8_t port)
{
    QM_Port::Select_Port(port);
    pinMode(_dat, INPUT_PULLUP);
    return (digitalRead(_dat));
}

bool QM_LineFollower::ReadSensor2(void)
{
    return (digitalRead(_clk));
}

bool QM_LineFollower::ReadSensor2(uint8_t port)
{
    QM_Port::Select_Port(port);
    pinMode(_clk, INPUT_PULLUP);
    return (digitalRead(_clk));
}
