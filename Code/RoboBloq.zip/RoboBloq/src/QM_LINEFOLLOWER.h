#ifndef RB_LineFollower_H
#define RB_LineFollower_H

#include <stdint.h>
#include <stdbool.h>
#include <Arduino.h>

#include "QM_PORT.h"
#define S1_IN_S2_IN (0X00)
#define S1_IN_S2_OUT (0X01)
#define S1_OUT_S2_IN (0X02)
#define S1_OUT_S2_OUT (0X03)

class QM_LineFollower : public QM_Port
{
public:
    QM_LineFollower(void);
    QM_LineFollower(uint8_t port);
    uint8_t ReadSensors(void);
    bool ReadSensor1(void);
    bool ReadSensor2(void);
    uint8_t ReadSensors(uint8_t port);
    bool ReadSensor1(uint8_t port);
    bool ReadSensor2(uint8_t port);

private:
    volatile uint8_t _Sensor1;
    volatile uint8_t _Sensor2;
};

#endif
