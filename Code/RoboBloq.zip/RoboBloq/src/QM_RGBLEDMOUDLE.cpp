#include "QM_RGBLEDMOUDLE.h"
#include "Adafruit_NeoPixel.h"

Adafruit_NeoPixel rgb_display_18 = Adafruit_NeoPixel(QM_MAX_LED_NUMBER, 18, NEO_GRB + NEO_KHZ800);
QM_Port RGBLedMoudle_port;

/*
 * 
 */
QM_RGBLedMoudle ::QM_RGBLedMoudle(uint8_t port)
{
    count_led = QM_MAX_LED_NUMBER;
    RGBLedMoudle_port.GPIO_Init();
    RGBLedMoudle_port.Select_Port(port);
    rgb_display_18.begin();
    rgb_display_18.setBrightness(50);
}

/*
  * 
  */
QM_RGBLedMoudle ::~QM_RGBLedMoudle(void)
{
}

bool QM_RGBLedMoudle::setColor(uint8_t index, uint8_t red, uint8_t green, uint8_t blue)
{
    if (index == 0)
    {
        for (int16_t i = 0; i < count_led; i++)
        {
            rgb_display_18.setPixelColor(i, ((red & 0xffffff) << 16) | ((green & 0xffffff) << 8) | blue);
        }
        return (true);
    }
    else
    {
        rgb_display_18.setPixelColor(index - 1, ((red & 0xffffff) << 16) | ((green & 0xffffff) << 8) | blue);
    }
    return (false);
}

bool QM_RGBLedMoudle::setColor(uint8_t red, uint8_t green, uint8_t blue)
{
    return (setColor(0, red, green, blue));
}

void QM_RGBLedMoudle::show(void)
{
    rgb_display_18.show();
    delay(1);
}
