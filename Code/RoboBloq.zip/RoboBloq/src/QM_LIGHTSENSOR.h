#ifndef QM_LightSensor_H
#define QM_LightSensor_H

#include <stdint.h>
#include <stdbool.h>
#include <Arduino.h>

#include "QM_PORT.h"

class QM_LightSensor : public QM_Port
{
public:
    QM_LightSensor(void);
    QM_LightSensor(uint8_t port);
    uint16_t GetLight(void);
    uint16_t GetLightValue(void);
    uint16_t GetLightValue(uint8_t port);

private:
    uint8_t _SigPin;
};

#endif
