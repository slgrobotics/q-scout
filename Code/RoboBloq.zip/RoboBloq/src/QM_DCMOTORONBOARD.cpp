
#include "QM_DCMOTORONBOARD.h"

ESP32MotorControl  Moter;

void QM_DcmotorOnBoard::QM_DcmotorOnBoard_Init(void)
{
    Moter.attachMotors(motor_AIN2,motor_AIN1,motor_BIN1,motor_BIN2);  
    digitalWrite(moter_sleep,HIGH);  // motor_sleep：wakeup motor driver

    delay(500);
}

void QM_DcmotorOnBoard::QM_DcmotorOnBoardM1_Run(int32_t speed)
{

    bool M_Dir = true;
    speed = constrain(speed, -100, 100);
    if (speed < 0)
    {
        M_Dir = false;
    }
    else
    {
        M_Dir = true;
    }

    if (M_Dir == true)
    {
        speed = abs(speed);
        if(speed > 95)
            speed = 100;
        Moter.motorForward(0,speed);
    }
    else
    {
        speed = abs(speed);
        if(speed > 95)
            speed = 100;
        Moter.motorReverse(0,speed);
    }
    _M1_Speed = speed;
}

void QM_DcmotorOnBoard::QM_DcmotorOnBoardM2_Run(int32_t speed)
{

    bool M_Dir = true;
    speed = constrain(speed, -100, 100);
    if (speed < 0)
    {
        M_Dir = false;
    }
    else
    {
        M_Dir = true;
    }

    if (M_Dir == true)
    {
        speed = abs(speed);
        if(speed > 95)
            speed = 100;
        Moter.motorForward(1,speed);
    }
    else
    {
        speed = abs(speed);
        if(speed > 95)
            speed = 100;
        Moter.motorReverse(1,speed);
    }
}

void QM_DcmotorOnBoard::run(int32_t speed1, int32_t speed2)
{
    QM_DcmotorOnBoard::QM_DcmotorOnBoardM1_Run(speed1);
    QM_DcmotorOnBoard::QM_DcmotorOnBoardM2_Run(speed2);
}

void QM_DcmotorOnBoard::stop(void)
{
    QM_DcmotorOnBoard::QM_DcmotorOnBoardM1_Run(0);
    QM_DcmotorOnBoard::QM_DcmotorOnBoardM2_Run(0);
}