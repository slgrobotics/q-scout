#ifndef QM_PIRSENSOR_H
#define QM_PIRSENSOR_H

#include <stdint.h>
#include <stdbool.h>
#include <Arduino.h>

#include "QM_PORT.h"

class QM_PirSensor
{
public:
    QM_PirSensor(void);
    QM_PirSensor(uint8_t port);
    void SetPin(uint8_t sigpin, uint8_t modepin);
    void SetPirMode(uint8_t Mode);
    uint8_t GetPirSensor(void);
    uint8_t GetPirSensor(uint8_t port);

private:
    volatile uint8_t _SigPin;
    volatile uint8_t _ModePin;
};

#endif
